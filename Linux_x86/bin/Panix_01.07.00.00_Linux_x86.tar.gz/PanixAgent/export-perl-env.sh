#!/bin/sh

#Incluimos archivo de Utileria
if [ "X${UTILS}" != "X1" ]
then
	. ${WORKINGDIR}/PanixAgent/CommonTools.sh
	UTILS=1
fi


# Se invoca este script en el mismo hilo de proceso y tiene disponible las variable ${WORKINGDIR}
PrintMessage 2 "Export-perl-env WORKINGDIR = ${WORKINGDIR}"

# Se busca la version de Perl empaquetada en Panix
PERL_VERS_BASE_DIR=`ls -d ${WORKINGDIR}/PanixAgent/perl/lib/*.*.* | sort -r | head -n 1`
PERL_VERS_SITE_DIR=`ls -d ${WORKINGDIR}/PanixAgent/perl/lib/site_perl/*.*.*  | sort -r | head -n 1`

XSDIR=$PERL_VERS_BASE_DIR


# Arquitecturas: IA64, PA-RISC 2.0, PPC, SPARC, AIX64, PPC64LE, x86
ARCH_DIR=`ls -d ${XSDIR}/*IA64* 2>/dev/null`
if [ "X${ARCH_DIR}" != "X" ]; then
	ARCH="IA64"
fi
ARCH_DIR=`ls -d ${XSDIR}/*PA-RISC* 2>/dev/null`
if [ "X${ARCH_DIR}" != "X" ]; then
	ARCH="PARISC"
fi
ARCH_DIR=`ls -d ${XSDIR}/*thread* 2>/dev/null`
if [ "X${ARCH_DIR}" != "X" ]; then
	ARCH="PPC"
fi
ARCH_DIR=`ls -d ${XSDIR}/sun4-solaris 2>/dev/null`
if [ "X${ARCH_DIR}" != "X" ]; then
	ARCH="SPARC"
fi
ARCH_DIR=`ls -d ${XSDIR}/*aix-64* 2>/dev/null`
if [ "X${ARCH_DIR}" != "X" ]; then
	ARCH="AIX64"
fi
ARCH_DIR=`ls -d ${XSDIR}/ppc64le-linux 2>/dev/null`
if [ "X${ARCH_DIR}" != "X" ]; then
	ARCH="PPC64LE"
fi
ARCH_DIR=`ls -d ${XSDIR}/*86* 2>/dev/null`
if [ "X${ARCH_DIR}" != "X" ]; then
        ARCH="x86"
fi

case ${ARCH} in
	"IA64")
		#Si arquitectura HP-UX IA64
		PrintMessage 2 "Perl lib IA-64 was found ";
		XSDIR=`ls -d ${PERL_VERS_BASE_DIR}/*IA64*`
		XSDIR=${XSDIR}:`ls -d ${PERL_VERS_SITE_DIR}/*IA64*`
	;;
	"PARISC")
		#Si arquitectura HP-UX PA-RISC 2.0
		PrintMessage 2 "Perl lib IA-64 was found ";
		XSDIR=`ls -d ${PERL_VERS_BASE_DIR}/*PA-RISC*`
		XSDIR=${XSDIR}:`ls -d ${PERL_VERS_SITE_DIR}/*PA-RISC*`
	;;
	"PPC")
		#Si arquitectura AIX (PowerPc)
		PrintMessage 2 "Perl lib PowerPC was found ";
		XSDIR=`ls -d ${PERL_VERS_BASE_DIR}/*thread*`
		XSDIR=${XSDIR}:`ls -d ${PERL_VERS_SITE_DIR}/*thread*`
	;;	
	"AIX64")
		#Si arquitectura AIX 64 (PowerPc)
		PrintMessage 2 "Perl lib PowerPC (AIX 64) was found ";
		XSDIR=`ls -d ${PERL_VERS_BASE_DIR}/*aix-64*`
		XSDIR=${XSDIR}:`ls -d ${PERL_VERS_SITE_DIR}/*aix-64*`
	;;
	"SPARC")
		#Si arquitectura Sun SPARC
		PrintMessage 2 "Perl lib Sun SPARC was found";
		XSDIR=`ls -d ${PERL_VERS_BASE_DIR}/sun4-solaris`
		XSDIR=${XSDIR}:`ls -d ${PERL_VERS_SITE_DIR}/sun4-solaris`
	;;
	"PPC64LE")
		#Si arquitectura PPC64 (PowerPc Linux)
		PrintMessage 2 "Perl lib PowerPC 64 (Linux)";
		XSDIR=`ls -d ${PERL_VERS_BASE_DIR}/ppc64le-linux`
		XSDIR=${XSDIR}:`ls -d ${PERL_VERS_SITE_DIR}/ppc64le-linux`
	;;
	"x86")
		#Si arquitectura intel 32/64 (x86)
		PrintMessage 2 "Perl lib INTEL was found ";
		XSDIR=`ls -d ${PERL_VERS_BASE_DIR}/*86*`
		XSDIR=${XSDIR}:`ls -d ${PERL_VERS_SITE_DIR}/*86*`
	;;
	*)
		PrintMessage 0 "No architecture found in Perl."
		exit 1
esac

PrintMessage 3 "Export-perl-env XSDIR = $XSDIR"
PrintMessage 3 "Export-perl-env PERL_VERS_BASE_DIR = $PERL_VERS_BASE_DIR"
PrintMessage 3 "Export-perl-env PERL_VERS_SITE_DIR = $PERL_VERS_SITE_DIR"

# For memconf
# Se anade /usr/sbin por si no esta en PATH (HPUX PA-RISC 11.11)
if [ -d /usr/sbin ]; then
	PATH=/usr/sbin:$PATH
fi
PATH=${WORKINGDIR}/PanixAgent/perl/bin:$PATH
PERL5LIB="${WORKINGDIR}/PanixAgent/perl/agent:$PERL_VERS_BASE_DIR:$PERL_VERS_SITE_DIR:$XSDIR"
LD_LIBRARY_PATH=${WORKINGDIR}/PanixAgent/perl/bin
LIBPATH=${WORKINGDIR}/PanixAgent/perl/bin
# should use unset instead
PERLLIB=""

export PATH
export PERL5LIB
export PERLLIB
export LD_LIBRARY_PATH
export LIBPATH
# Si es HPUX ponemos el modo XPG4 para tener los parametros de ps y mostrar los procesos
if [ "X${ARCH}" = "XIA64" ] || [ "X${ARCH}" = "XPARISC" ]; then
        export UNIX95=
fi

PrintMessage 2 "Export-perl-env PATH = $PATH"
PrintMessage 2 "Export-perl-env PERL5LIB = $PERL5LIB"
PrintMessage 2 "Export-perl-env PERLLIB = $PERLLIB"
PrintMessage 2 "Export-perl-env LD_LIBRARY_PATH = $LD_LIBRARY_PATH"
PrintMessage 2 "Export-perl-env LIBPATH = $LIBPATH"
if [ "X${ARCH}" = "XIA64" ] || [ "X${ARCH}" = "XPARISC" ]; then
        PrintMessage 2 "Export-perl-env UNIX95="
fi
