#!/bin/sh
################################################################################
# Product:		ProactivaNET
# Application:	EspiralMS.ProactivaNET.Panix
#
# File:			CommonTools.sh
# Description:	Bash script for launching panix.pl
# 
# Author:		equipossaa@espiralms.com
# 
# Date: 	2021-02-04
# 
################################################################################
#
# Comments: Common Methos forr Panix
#
################################################################################

################################################################################
# GLOBAL VARIABLES
################################################################################
if [ "X${VERBOSITYLEVEL}" = "X" ]
then
	VERBOSITYLEVEL=0				# Nivel de verbosidad
fi


################################################################################
# Funcion que devuelve el nivel de verbosidad
# Parámetros:
################################################################################
VerbosityLevel()
{
	VERBOSITYLEVEL=0
	while [ "X$#" != "X0" ]
	do
		PARAMETER=$1
		# Caso fusioninventory-injector -v o --verbose a secas (no es -v=3)
		if [ "$PARAMETER" = "-v" ] || [ "$PARAMETER" = "--verbose" ]; then
			VERBOSITYLEVEL=3
		else
			KEY=`echo ${PARAMETER} | cut -d = -f 1`
			VALUE=`echo ${PARAMETER} | cut -d = -f 2`

			case ${KEY} in
				"-v" | "--verbose")
					VERBOSITYLEVEL=${VALUE}
					;;
				"-d" | "--debug")
					VERBOSITYLEVEL=3
					;;
			esac
		fi
		shift
	done
}


################################################################################
# Funcion que imprime un mensaje en función de
# de la verbosidad.
# Parámetros:
# Nivel 0 -> Error, 1 -> Warning, 2 -> Info, 3 -> Debug
# Mensaje
################################################################################
PrintMessage()
{
	if [ $1 -le $VERBOSITYLEVEL ]
	then
		PREFIX=""
		case $1 in
			"0")
				PREFIX="[ERROR]"
				;;
			"1")
				PREFIX="[WARNING]"
				;;
			"2")
				PREFIX="[INFO]"
				;;
			"3")
				PREFIX="[DEBUG]"
				;;
		esac
		echo "${PREFIX} $2"

	fi
}


################################################################################
# Funcion que obtiene y copia las librerías dinámicas necesarias para ejecutarse
# Parámetros:
# BINARYFILE binario a comprobar dependencias
# OBLIGED binario obligatorio 1 o no 0. Default 1
# Return:
# 0 si es OK, 1 si es warning, -1 si es error 
################################################################################

GetLibrariesFromFile()
{
	BINARYFILE=$1
	OBLIGED=$2
	RETVAL=0

	
	# obtener librerias que no encuentra y copiarlas si estan disponibles
	# AIX tiene un formato diferente de ldd y no se puede aplicar recursividad. Si se trata de un .a se finaliza
	if [ "X$ARCH" = "XAIX64" ]; then
		EXTENSION=`echo ${BINARYFILE}| awk -F. '{print $NF}'`
		if [ "X${EXTENSION}" = "Xa" ]; then 
			PrintMessage 2 "No binary file, don't check: ${BINARYFILE}"
			return $RETVAL
		else
			LIBS_NOTFOUND=`ldd ${BINARYFILE} 2>&1 > /dev/null|grep "Cannot find"|cut -d "(" -f1|awk '{print $NF}'`
		fi
	# Resto SO que no son AIX
	else 
		LIBS_NOTFOUND=`ldd ${BINARYFILE}|grep "not found"|awk '{print $1}' 2> /dev/null`
	fi

	# Comprobar si hay ldd, sino mensaje retornar warning
	if [ $? -ne 0 ]; then
		PrintMessage 1 "Can't execute binary: ldd"
		RETVAL=1
	# recorrer cada libreria no encontrada y copiarla
	else
		for LIB in $LIBS_NOTFOUND
		do
			if [ -f ${WORKINGDIR}/PanixAgent/perl/bin/lib_repo/${LIB} ]; then
				if [ ! -f ${WORKINGDIR}/PanixAgent/perl/bin/${LIB} ]; then
					cp ${WORKINGDIR}/PanixAgent/perl/bin/lib_repo/${LIB} ${WORKINGDIR}/PanixAgent/perl/bin/
					PrintMessage 2 "cp ${WORKINGDIR}/PanixAgent/perl/bin/lib_repo/${LIB} ${WORKINGDIR}/PanixAgent/perl/bin/"
				else
					PrintMessage 3 "No copy, already exists: ${WORKINGDIR}/PanixAgent/perl/bin/${LIB}"
				fi
				# buscar recursivamente si faltan librerias
				GetLibrariesFromFile ${WORKINGDIR}/PanixAgent/perl/bin/${LIB} $OBLIGED
				RETVAL=$?
			else
				# imprimir mensaje warning o error
				if [ "X$OBLIGED" = "X0" ]; then
					PrintMessage 1 "${LIB} not found"
					RETVAL=1
				else
					PrintMessage 0 "${LIB} not found"
					RETVAL=-1
				fi
			fi
		done
	fi

	return $RETVAL
}